<?php
    $lnk = mysql_connect("127.0.0.1", "pentesterlab", "pentesterlab");
    $db = mysql_select_db('cr', $lnk);
?>
